import React from 'react'

function Navbaar() {
  return (
    <div>
      <Navbaar>
        <h3>HOME</h3>
        <h2>NEW</h2>
        <H2>CONTACTS</H2>
      </Navbaar>
    </div>
  )
}

export default Navbaar;
